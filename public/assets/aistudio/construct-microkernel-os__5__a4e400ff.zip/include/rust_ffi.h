/* Construct-OS Rust Allocator FFI Header */
#ifndef CONSTRUCT_RUST_FFI_H
#define CONSTRUCT_RUST_FFI_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

void construct_mm_init(uintptr_t memory_base, size_t total_frames);
uintptr_t construct_frame_alloc(void);
int32_t construct_frame_free(uintptr_t phys_addr);
size_t construct_allocated_count(void);

#ifdef __cplusplus
}
#endif

#endif /* CONSTRUCT_RUST_FFI_H */
