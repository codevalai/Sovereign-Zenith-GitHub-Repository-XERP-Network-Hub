{
  description = "Hermetic Toolchain for Construct-MicroKernel-OS";
  inputs = {
    nixpkgs.url = "github:nixos/nixpkgs/nixos-unstable";
    rust-overlay.url = "github:oxalica/rust-overlay";
  };
  outputs = { self, nixpkgs, rust-overlay }:
    let
      system = "x86_64-linux";
      pkgs = import nixpkgs {
        inherit system;
        overlays = [ (import rust-overlay) ];
      };
      rustToolchain = pkgs.rust-bin.nightly.latest.default.override {
        targets = [ "x86_64-unknown-none" ];
        extensions = [ "rust-src" ];
      };
    in {
      devShells.${system}.default = pkgs.mkShell {
        buildInputs = [
          rustToolchain
          pkgs.qemu
          pkgs.xorriso
          pkgs.grub2
          pkgs.gnumake
          pkgs.llvmPackages.clang
          pkgs.llvmPackages.lld
        ];
      };
    };
}
