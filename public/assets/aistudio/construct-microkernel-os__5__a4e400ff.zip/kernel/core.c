/* Construct-MicroKernel-OS // Ring-0 Preemptive Kernel Core, UART Driver & Capability IPC */
#include <stdint.h>
#include <stddef.h>
#include "../include/rust_ffi.h"

#define MAX_TASKS 64
#define IPC_MSG_WORDS 8
#define COM1_PORT 0x3F8

/* Freestanding x86_64 Port I/O Routines */
static inline void outb(uint16_t port, uint8_t val) {
    __asm__ volatile ("outb %0, %1" : : "a"(val), "Nd"(port));
}

static inline uint8_t inb(uint16_t port) {
    uint8_t ret;
    __asm__ volatile ("inb %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

/* COM1 (0x3F8) UART Driver for Serial Telemetry */
static void uart_init(void) {
    outb(COM1_PORT + 1, 0x00);    /* Disable UART interrupts */
    outb(COM1_PORT + 3, 0x80);    /* Enable DLAB (set baud rate divisor) */
    outb(COM1_PORT + 0, 0x03);    /* Set divisor to 3 (38400 baud) */
    outb(COM1_PORT + 1, 0x00);
    outb(COM1_PORT + 3, 0x03);    /* 8 bits, no parity, one stop bit */
    outb(COM1_PORT + 2, 0xC7);    /* Enable FIFO, clear them with 14-byte threshold */
    outb(COM1_PORT + 4, 0x0B);    /* IRQs enabled, RTS/DSR set */
}

static int uart_is_transmit_empty(void) {
    return inb(COM1_PORT + 5) & 0x20;
}

void uart_putc(char c) {
    while (!uart_is_transmit_empty());
    outb(COM1_PORT, (uint8_t)c);
}

void uart_puts(const char* s) {
    while (*s) {
        if (*s == '\n') uart_putc('\r');
        uart_putc(*s++);
    }
}

typedef enum {
    TASK_READY = 0,
    TASK_RUNNING = 1,
    TASK_BLOCKED_IPC = 2,
    TASK_ZOMBIE = 3
} task_state_t;

typedef struct {
    uint64_t sender_tid;
    uint64_t badge;
    uint64_t words[IPC_MSG_WORDS];
} ipc_msg_t;

typedef struct {
    uint64_t tid;
    uint64_t rsp;
    uint64_t deadline_ticks;
    uint64_t capability_mask;
    task_state_t state;
    ipc_msg_t ipc_buffer;
} tcb_t;

static tcb_t task_table[MAX_TASKS];
static size_t current_task_idx = 0;
static volatile uint64_t system_ticks = 0;

void kernel_init(void) {
    /* 1. Initialize COM1 Serial Telemetry */
    uart_init();
    uart_puts("\n[RING-0] Construct-OS Kernel v2.5.0 Online\n");
    uart_puts("[RING-0] 64-Bit Long Mode Active // Identity Paging 1GB Established\n");

    /* 2. Initialize Freestanding Rust Frame Allocator */
    construct_mm_init(0x200000, 1024);
    uart_puts("[RING-0] Rust Frame Allocator Initialized @ 0x200000 (1024 4KB Frames)\n");

    /* 3. Setup Preemptive Task Control Blocks */
    for (size_t i = 0; i < MAX_TASKS; ++i) {
        task_table[i].tid = i;
        task_table[i].state = (i == 0) ? TASK_RUNNING : TASK_ZOMBIE;
        task_table[i].deadline_ticks = (i == 0) ? 10 : UINT64_MAX;
        task_table[i].capability_mask = (i == 0) ? ~0ULL : 0x0FULL;
    }
    current_task_idx = 0;
    uart_puts("[RING-0] EDF Preemptive Scheduler Ready (Init Task #0 Active)\n");
}

tcb_t* schedule_next(void) {
    system_ticks++;
    size_t best_idx = 0;
    uint64_t earliest = UINT64_MAX;

    for (size_t i = 0; i < MAX_TASKS; ++i) {
        if (task_table[i].state == TASK_READY || task_table[i].state == TASK_RUNNING) {
            if (task_table[i].deadline_ticks <= earliest) {
                earliest = task_table[i].deadline_ticks;
                best_idx = i;
            }
        }
    }

    if (task_table[current_task_idx].state == TASK_RUNNING && current_task_idx != best_idx) {
        task_table[current_task_idx].state = TASK_READY;
    }

    current_task_idx = best_idx;
    task_table[current_task_idx].state = TASK_RUNNING;
    return &task_table[current_task_idx];
}

int sys_ipc_send(uint64_t dest_tid, const ipc_msg_t* msg) {
    if (dest_tid >= MAX_TASKS || !msg) {
        return -1;
    }

    tcb_t* caller = &task_table[current_task_idx];
    if ((caller->capability_mask & (1ULL << (dest_tid & 63))) == 0) {
        return -2; /* EPERM: Capability badge rejected */
    }

    tcb_t* target = &task_table[dest_tid];
    target->ipc_buffer.sender_tid = caller->tid;
    target->ipc_buffer.badge = caller->capability_mask;
    for (size_t w = 0; w < IPC_MSG_WORDS; ++w) {
        target->ipc_buffer.words[w] = msg->words[w];
    }

    if (target->state == TASK_BLOCKED_IPC) {
        target->state = TASK_READY;
    }
    return 0;
}

int sys_task_spawn(uint64_t deadline_offset, uint64_t caps) {
    for (size_t i = 1; i < MAX_TASKS; ++i) {
        if (task_table[i].state == TASK_ZOMBIE) {
            uintptr_t stack_page = construct_frame_alloc();
            if (!stack_page) return -3; /* ENOMEM */

            task_table[i].rsp = stack_page + 4096;
            task_table[i].deadline_ticks = system_ticks + deadline_offset;
            task_table[i].capability_mask = caps;
            task_table[i].state = TASK_READY;
            return (int)i;
        }
    }
    return -4; /* EAGAIN: Process table full */
}
