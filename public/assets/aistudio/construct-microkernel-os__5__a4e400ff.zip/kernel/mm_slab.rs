#![no_std]

use core::cell::UnsafeCell;
use core::panic::PanicInfo;

#[panic_handler]
fn panic(_info: &PanicInfo) -> ! {
    loop {}
}

pub const PAGE_SIZE: usize = 4096;
pub const MAX_FRAMES: usize = 1024; // 1024 frames of 4KB = 4MB physical pool starting at 0x200000

pub struct FrameAllocator {
    bitmap: [u64; MAX_FRAMES / 64],
    allocated_count: usize,
    base_address: usize,
}

struct SafeFrameAllocator(UnsafeCell<FrameAllocator>);
unsafe impl Sync for SafeFrameAllocator {}

static GLOBAL_ALLOCATOR: SafeFrameAllocator = SafeFrameAllocator(UnsafeCell::new(FrameAllocator {
    bitmap: [0; MAX_FRAMES / 64],
    allocated_count: 0,
    base_address: 0x200000,
}));

impl FrameAllocator {
    pub fn alloc(&mut self) -> Option<usize> {
        for (word_idx, word) in self.bitmap.iter_mut().enumerate() {
            if *word != u64::MAX {
                let bit = (!*word).trailing_zeros() as usize;
                *word |= 1u64 << bit;
                self.allocated_count += 1;
                return Some(self.base_address + (word_idx * 64 + bit) * PAGE_SIZE);
            }
        }
        None
    }

    pub fn free(&mut self, phys_addr: usize) -> Result<(), &'static str> {
        if phys_addr < self.base_address {
            return Err("Address below frame pool");
        }
        let offset = phys_addr - self.base_address;
        let frame_idx = offset / PAGE_SIZE;
        if frame_idx >= MAX_FRAMES {
            return Err("Frame index out of bounds");
        }
        let word_idx = frame_idx / 64;
        let bit = frame_idx % 64;
        if (self.bitmap[word_idx] & (1u64 << bit)) == 0 {
            return Err("Double-free prevented by Construct Slab Guard");
        }
        self.bitmap[word_idx] &= !(1u64 << bit);
        self.allocated_count -= 1;
        Ok(())
    }
}

#[no_mangle]
pub extern "C" fn construct_mm_init(base: usize, _frames: usize) {
    let alloc = unsafe { &mut *GLOBAL_ALLOCATOR.0.get() };
    alloc.base_address = if base != 0 { base } else { 0x200000 };
    alloc.allocated_count = 0;
    for w in alloc.bitmap.iter_mut() {
        *w = 0;
    }
}

#[no_mangle]
pub extern "C" fn construct_frame_alloc() -> usize {
    let alloc = unsafe { &mut *GLOBAL_ALLOCATOR.0.get() };
    alloc.alloc().unwrap_or(0)
}

#[no_mangle]
pub extern "C" fn construct_frame_free(phys_addr: usize) -> i32 {
    let alloc = unsafe { &mut *GLOBAL_ALLOCATOR.0.get() };
    match alloc.free(phys_addr) {
        Ok(()) => 0,
        Err(_) => -1,
    }
}

#[no_mangle]
pub extern "C" fn construct_allocated_count() -> usize {
    let alloc = unsafe { &*GLOBAL_ALLOCATOR.0.get() };
    alloc.allocated_count
}
