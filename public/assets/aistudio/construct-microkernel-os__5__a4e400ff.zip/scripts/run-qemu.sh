#!/usr/bin/env bash
# Headless & Serial QEMU Runner for Construct-MicroKernel-OS
set -euo pipefail

KERNEL_BIN="build/kernel.bin"
if [ ! -f "$KERNEL_BIN" ]; then
    echo "[*] Target $KERNEL_BIN not found. Triggering automated build..."
    make all
fi

echo "[*] Booting Construct-MicroKernel-OS in QEMU x86_64..."
if command -v qemu-system-x86_64 >/dev/null 2>&1; then
    exec qemu-system-x86_64 -kernel "$KERNEL_BIN" -serial stdio -display none -m 128M
else
    echo "[!] qemu-system-x86_64 is not installed in local environment."
    echo "[!] Use Nix shell ('nix develop') or run inside the provided CI container."
    exit 0
fi
