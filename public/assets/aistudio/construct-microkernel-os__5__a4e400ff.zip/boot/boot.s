/* Construct-MicroKernel-OS // Multiboot2 & 64-Bit Long Mode Trampoline */
.code32
.set MULTIBOOT2_MAGIC, 0xe85250d6
.set ARCHITECTURE,     0
.set HEADER_LENGTH,    multiboot_header_end - multiboot_header

.section .multiboot
.align 8
multiboot_header:
    .long MULTIBOOT2_MAGIC
    .long ARCHITECTURE
    .long HEADER_LENGTH
    .long -(MULTIBOOT2_MAGIC + ARCHITECTURE + HEADER_LENGTH)

    /* End Tag */
    .short 0
    .short 0
    .long 8
multiboot_header_end:

.section .bss
.align 4096
pml4_table:
    .skip 4096
pdpt_table:
    .skip 4096
pd_table:
    .skip 4096

.align 16
stack_bottom:
    .skip 32768
stack_top:

.section .rodata
.align 8
gdt64:
    .quad 0                         /* 0x00: Null descriptor */
    .quad 0x00209a0000000000        /* 0x08: 64-bit Code descriptor (Present, Ring 0, Exec/Read, Long Mode 64) */
    .quad 0x0000920000000000        /* 0x10: 64-bit Data descriptor (Present, Ring 0, Read/Write) */
gdt64_desc:
    .word . - gdt64 - 1
    .quad gdt64

.section .text
.global _start
.type _start, @function
_start:
    cli

    /* Save multiboot2 info pointers */
    mov %eax, %esi                  /* magic */
    mov %ebx, %edi                  /* multiboot info pointer */

    /* Set up initial 32-bit stack */
    mov $stack_top, %esp

    /* 1. Build 4-level identity page tables covering first 1GB */
    /* Point PML4 entry 0 to PDPT with flags (Present | Writable = 0x03) */
    mov $pdpt_table, %eax
    or $0x03, %eax
    mov %eax, pml4_table

    /* Point PDPT entry 0 to PD with flags (Present | Writable = 0x03) */
    mov $pd_table, %eax
    or $0x03, %eax
    mov %eax, pdpt_table

    /* Map 512 entries of 2MB huge pages in PD (512 * 2MB = 1GB identity mapped) */
    mov $0, %ecx                    /* Loop counter 0..511 */
.map_pd_table:
    mov $0x200000, %eax             /* 2MB */
    mul %ecx                        /* EAX = ECX * 2MB */
    or $0x83, %eax                  /* Present | Writable | Huge (0x80 | 0x02 | 0x01) */
    mov %eax, pd_table(, %ecx, 8)
    inc %ecx
    cmp $512, %ecx
    jne .map_pd_table

    /* 2. Load PML4 into CR3 */
    mov $pml4_table, %eax
    mov %eax, %cr3

    /* 3. Enable PAE (Physical Address Extension) in CR4 (bit 5) */
    mov %cr4, %eax
    or $0x20, %eax
    mov %eax, %cr4

    /* 4. Enable Long Mode in EFER MSR (MSR 0xC0000080, bit 8: LME) */
    mov $0xc0000080, %ecx
    rdmsr
    or $0x00000100, %eax
    wrmsr

    /* 5. Enable Paging (bit 31) and Protected Mode (bit 0) in CR0 */
    mov %cr0, %eax
    or $0x80000001, %eax
    mov %eax, %cr0

    /* 6. Load 64-bit GDT */
    lgdt (gdt64_desc)

    /* 7. Far jump into 64-bit code segment (0x08) */
    ljmp $0x08, $long_mode_start

.code64
long_mode_start:
    /* Reload data segment registers with 64-bit data segment (0x10) */
    mov $0x10, %ax
    mov %ax, %ds
    mov %ax, %es
    mov %ax, %fs
    mov %ax, %gs
    mov %ax, %ss

    /* Setup 64-bit long-mode stack pointer */
    mov $stack_top, %rsp

    /* Zero out base pointer for clean stack traces */
    xor %rbp, %rbp

    /* Call Ring-0 Freestanding C/Rust Kernel Entry */
    call kernel_init

halt_loop64:
    hlt
    jmp halt_loop64
